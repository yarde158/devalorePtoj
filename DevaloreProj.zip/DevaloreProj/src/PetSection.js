import styled from "styled-components";

const Form = styled.div`
  padding: 1rem;
  margin: auto;
  background: #f0ebe1;
  margin-bottom: 0.5rem;

  & input {
    padding: 1rem;
    width: 90%;
    max-width: 20rem;
  }

  & label {
    display: block;
    font-weight: bold;
  }

  & input {
    font: inherit;
    display: block;
    width: 100%;
    border: 1px solid #ccc;
    padding: 0.15rem;
  }

  & input:focus {
    outline: none;
    border-color: #4f005f;
  }
`;

const PetSection = () => {
  return (
    <Form>
      <form>
        <div>
          <label>Pet name</label>
        </div>
        <input type="text"></input>
        <div>
          <div>
            <label>pet Type</label>
          </div>
          <select>
            <option value="Horse">Horse</option>
            <option>Cat</option>
            <option value="Dog">Dog</option>
          </select>
        </div>
        <button type="submit">next</button>
      </form>
    </Form>
  );
};
export default PetSection;
