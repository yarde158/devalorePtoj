import styled from "styled-components";
const Text = styled.div`
  text-align: center;
  padding: 1rem;
  background: #f0ebe1;
`;
const AgreementSection = () => {
  return (
    <Text>
      <Text>
        Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod
        tempor incididunt ut labore et dolore magna aliqua. Mi tempus imperdiet
        nulla malesuada pellentesque elit. Egestas congue quisque egestas diam
        in. Tempor orci dapibus ultrices in iaculis nunc. Viverra nibh cras
        pulvinar mattis nunc sed blandit. Pellentesque sit amet porttitor eget
        dolor morbi non arcu. Eu volutpat odio facilisis mauris. Mauris in
        aliquam sem fringilla ut morbi tincidunt augue interdum. Pulvinar sapien
        et ligula ullamcorper malesuada proin libero nunc. Sodales ut etiam sit
        amet.
      </Text>
      <div>
        <label>
          <input type="checkbox" />
          agreement all the data you entered till here
        </label>
        <div>
          <button> submit</button>
        </div>
      </div>
    </Text>
  );
};

export default AgreementSection;
