import { createSlice } from "@reduxjs/toolkit";

const initialState = { name: null, age: true };
const userSlice = createSlice({
  name: "userSectionSlice",
  initialState,
  reducers: {
    saveInput(state, action) {
      state.name = action.payload.name;
      state.age = action.payload.age;
    },
  },
});

export const userSliceActions = userSlice.actions;
export default userSlice.reducer;
