import { configureStore } from "@reduxjs/toolkit";
import userReduer from "./userSlice";

const store = configureStore({
  reducer: { userInput: userReduer },
});
export default store;
