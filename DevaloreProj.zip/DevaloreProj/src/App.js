import Card from "./components/Card";
import UserSection from "./userSection";
import PetSection from "./PetSection";
import AgreementSection from "./AgreementSection";
function App() {
  return (
    <Card>
      <UserSection></UserSection>
      <PetSection />
      <AgreementSection />
    </Card>
  );
}

export default App;
