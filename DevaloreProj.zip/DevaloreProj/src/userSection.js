import { useState } from "react";
import styled from "styled-components";
import { useDispatch } from "react-redux";
import { userSliceActions } from "./store/userSlice";
const Form = styled.div`
  padding: 1rem;

  background: #f0ebe1;
  margin-bottom: 0.5rem;

  & input {
    padding: 1rem;
    width: 90%;
    max-width: 20rem;
  }

  & label {
    display: block;
    font-weight: bold;
  }

  & input {
    font: inherit;
    display: block;
    width: 100%;
    border: 1px solid #ccc;
    padding: 0.15rem;
  }

  & input:focus {
    outline: none;
    border-color: #4f005f;
  }
`;

const UserSection = () => {
  const dispatch = useDispatch();
  const [name, setUserName] = useState("");
  const [age, setAge] = useState("");

  const nameHandler = (event) => {
    setUserName(event.target.value);
  };

  const ageHandler = (event) => {
    setAge(event.target.value);
  };

  const nameSectionSubmitHandler = (event) => {
    event.preventDefault();
    //cheacking if the name and age length isnt empty
    if (name.trim().length === 0 || age.trim().length === 0) {
      console.log(name + " " + age);
      return;
    }
    if (+age < 1) {
      return;
    }
    dispatch(userSliceActions.saveInput(name));
  };
  return (
    <Form>
      <form onSubmit={nameSectionSubmitHandler}>
        <div>
          <label value={name}>name</label>
        </div>
        <input onChange={nameHandler} type="text"></input>
        <div>
          <div>
            <label value={age}>Age(years)</label>
          </div>
          <input onChange={ageHandler} type="number"></input>
        </div>
        <button type="submit">next</button>
      </form>
    </Form>
  );
};

export default UserSection;
